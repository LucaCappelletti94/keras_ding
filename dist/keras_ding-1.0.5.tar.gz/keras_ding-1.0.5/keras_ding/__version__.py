"""Current version of package keras_ding"""
__version__ = "1.0.5"